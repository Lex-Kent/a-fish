'use client';

import { useState, useRef, useEffect } from 'react';

interface SearchingAnimationProps {
  isDark?: boolean;
}

export function SearchingAnimation({ isDark = true }: SearchingAnimationProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    const video = videoRef.current;
    if (video) {
      video.play().catch(console.error);
    }

    // Keep animation visible for minimum 12 seconds
    const timer = setTimeout(() => {
      setIsVisible(false);
    }, 12000);

    return () => clearTimeout(timer);
  }, []);

  const videoSrc = isDark 
    ? '/videos/finSearchDark.mp4' 
    : '/videos/finSearchLight.mp4';

  if (!isVisible) return null;

  return (
    <div className="flex flex-col items-center justify-center py-16">
      <div className="relative w-56 h-56 rounded-2xl overflow-hidden border-2 border-[#2a3544] shadow-2xl">
        <video
          ref={videoRef}
          src={videoSrc}
          loop
          muted
          playsInline
          className="w-full h-full object-cover"
        />
      </div>
      
      <div className="mt-10 text-center">
        <div className="text-2xl font-semibold tracking-tight">Deep Searching...</div>
        <div className="text-slate-400 mt-2">Fin is diving into our secure document library</div>
      </div>
    </div>
  );
}