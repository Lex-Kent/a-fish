'use client';

import { useState, useRef, useEffect } from 'react';
import { Sidebar } from '../src/components/Sidebar';
import { ProfileHeader } from '../src/components/ProfileHeader';
import { SearchFiltersPanel, SearchFilters } from '../src/components/SearchFilters';
import { SearchInput } from '../src/components/SearchInput';
import { ChatMessage, Message, DocumentCitation } from '../src/components/ChatMessage';
import { ThemeToggle } from '../src/components/ThemeToggle';
import { SearchingAnimation } from '../src/components/SearchingAnimation';
import { FloatingBubbles } from '../src/components/FloatingBubbles';
import { ChevronLeft, ChevronRight, Lock } from 'lucide-react';

interface Conversation {
  id: string;
  title: string;
  timestamp: Date;
  messages: Message[];
  filters: SearchFilters;
}

const MOCK_CITATIONS: DocumentCitation[] = [
  {
    id: '1',
    title: 'AML Compliance Framework 2025',
    path: '/documents/compliance/AML_Framework_2025.pdf',
    snippet: 'Updated anti-money laundering procedures and customer due diligence requirements in accordance with FCA regulations.',
    type: 'PDF',
    category: 'AML & KYC'
  },
  {
    id: '2',
    title: 'FINRA Filing - Q4 2025',
    path: '/documents/regulatory/FINRA_Q4_2025.xlsx',
    snippet: 'Quarterly regulatory filing submitted to FINRA detailing trading activity, client complaints, and compliance attestations.',
    type: 'Excel',
    category: 'Regulatory Filings'
  }
];

export default function AFishApp() {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [currentConversation, setCurrentConversation] = useState<Conversation | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [searchMode, setSearchMode] = useState<'deep-dive' | 'surface-skim'>('deep-dive');
  const [filters, setFilters] = useState<SearchFilters>({
    documentTypes: ['All Documents'],
    categories: ['All Categories'],
    timePeriod: 'all',
    dateFrom: '',
    dateTo: ''
  });

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [currentConversation?.messages]);

  const generateAIResponse = (userQuery: string) => ({
    content: `I've searched our internal document library and found relevant information.`,
    confidence: 92
  });

  const handleSendMessage = (query: string, files?: File[]) => {
    if (!query.trim() && (!files || files.length === 0)) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: query || `Uploaded ${files?.length} file(s)`,
      timestamp: new Date()
    };

    let conversation = currentConversation;

    if (!conversation) {
      conversation = {
        id: Date.now().toString(),
        title: query.slice(0, 50) || 'New Conversation',
        timestamp: new Date(),
        messages: [],
        filters: { ...filters }
      };
      setConversations(prev => [conversation!, ...prev]);
    }

    conversation = {
      ...conversation,
      messages: [...conversation.messages, userMessage],
      filters: { ...filters }
    };

    setCurrentConversation(conversation);
    setIsLoading(true);

    setTimeout(() => {
      const response = generateAIResponse(query);
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response.content,
        citations: MOCK_CITATIONS,
        timestamp: new Date(),
        confidence: response.confidence,
        saved: false
      };

      const updated = {
        ...conversation!,
        messages: [...conversation!.messages, aiMessage]
      };

      setCurrentConversation(updated);
      setConversations(prev => prev.map(c => c.id === updated.id ? updated : c));
      setIsLoading(false);
    }, 12000);
  };

  const handleNewConversation = () => setCurrentConversation(null);

  const sidebarLogo = isDarkMode ? "/images/finLogoSquareOnDark.png" : "/images/finLogoSquareOnWhite.png";
  const headerLogo = isDarkMode ? "/images/finLogoLongOnDark.png" : "/images/finLogoLongOnWhite.png";

  return (
    <div className="h-screen flex flex-col overflow-hidden bg-[#151B25] text-white">
      <FloatingBubbles />

      <div className="px-6 py-2 text-xs flex items-center justify-center gap-2 bg-[#070b0f] border-b border-[#2a3544]">
        <Lock className="w-3 h-3" /> Fully private • Nothing leaves our environment • All responses are auditable
      </div>

      <div className="flex flex-1 overflow-hidden relative">
        <Sidebar
          conversations={conversations}
          onSelectConversation={(conv) => setCurrentConversation(conv)}
          onNewConversation={handleNewConversation}
          selectedConversationId={currentConversation?.id}
          isDark={isDarkMode}
          isCollapsed={isSidebarCollapsed}
          logo={sidebarLogo}
        />

        <button
          onClick={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
          className="fixed top-1/2 z-50 p-2 rounded-r-lg bg-[#1e2632] border border-[#2a3544] hover:bg-[#243040]"
          style={{ left: isSidebarCollapsed ? '64px' : '256px' }}
        >
          {isSidebarCollapsed ? <ChevronRight size={18} /> : <ChevronLeft size={18} />}
        </button>

        <div className="flex-1 flex flex-col" style={{ marginLeft: isSidebarCollapsed ? '64px' : '256px' }}>
          <header className="border-b border-[#2a3544] px-6 py-4 flex-shrink-0 bg-[#1a2332]">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                {isSidebarCollapsed && (
                  <img src={headerLogo} alt="a•fish" className="h-10 w-auto" />
                )}
              </div>

              <div className="flex items-center gap-4">
                <ThemeToggle isDark={isDarkMode} onToggle={() => setIsDarkMode(!isDarkMode)} />
                <ProfileHeader 
                  userName="Sam Samson" 
                  userEmail="sam.samson@moneymatters.com" 
                  isDark={isDarkMode} 
                />
              </div>
            </div>
          </header>

          <div className="flex-1 overflow-auto p-8">
            {!currentConversation || currentConversation.messages.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center">
                <img 
                  src="/images/finHello.png" 
                  alt="Fin" 
                  className="w-64 h-64 object-contain mb-8" 
                />
                <h2 className="text-4xl font-semibold mb-3">Hi, I'm Fin.</h2>
                <p className="text-xl text-slate-400 mb-6">What are we fishing for today?</p>
                <p className="text-slate-400 mb-12 max-w-md">
                  Ask me anything about our internal documents, policies, and reports.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-2xl w-full">
                  <button onClick={() => handleSendMessage("Summarise our current AML policy")} className="p-5 text-left rounded-2xl border border-[#2a3544] hover:bg-[#1e2632] transition-all">Summarise our current AML policy</button>
                  <button onClick={() => handleSendMessage("What were the key findings from the last FINRA review?")} className="p-5 text-left rounded-2xl border border-[#2a3544] hover:bg-[#1e2632] transition-all">What were the key findings from the last FINRA review?</button>
                  <button onClick={() => handleSendMessage("Show me our latest KYC guidelines")} className="p-5 text-left rounded-2xl border border-[#2a3544] hover:bg-[#1e2632] transition-all">Show me our latest KYC guidelines</button>
                  <button onClick={() => handleSendMessage("What are the current trading desk compliance rules?")} className="p-5 text-left rounded-2xl border border-[#2a3544] hover:bg-[#1e2632] transition-all">What are the current trading desk compliance rules?</button>
                </div>
              </div>
            ) : (
              <div className="max-w-4xl mx-auto">
                {currentConversation.messages.map((msg) => (
                  <ChatMessage 
                    key={msg.id} 
                    message={msg} 
                    userName="Sam Samson" 
                    isDark={isDarkMode}
                  />
                ))}
                {isLoading && <SearchingAnimation isDark={isDarkMode} />}
              </div>
            )}
          </div>

          <div className="border-t border-[#2a3544] bg-[#1a2332] p-6">
            <div className="max-w-4xl mx-auto">
              <SearchFiltersPanel filters={filters} onFiltersChange={setFilters} isDark={isDarkMode} />
              <SearchInput
                onSubmit={handleSendMessage}
                isLoading={isLoading}
                isDark={isDarkMode}
                searchMode={searchMode}
                onSearchModeChange={setSearchMode}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}